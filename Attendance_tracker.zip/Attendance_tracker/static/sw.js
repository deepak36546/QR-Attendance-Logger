// Simple Service Worker to trigger PWA installability
self.addEventListener('install', (e) => {
    console.log('[Service Worker] Installed');
});

self.addEventListener('fetch', (e) => {
    e.respondWith(fetch(e.request));
});